// // 6
// function tushirMassiv(arr: number[], tushirishSoni: number): number[] {
//   return arr.slice(tushirishSoni);
// }
// console.log(tushirMassiv([1, 2, 3, 4, 5], 2));

// // 47
// function ovozlar(ovozObj: { upvotes: number, downvotes: number }): number {
//   return ovozObj.upvotes - ovozObj.downvotes;
// }
// console.log(ovozlar({ upvotes: 100, downvotes: 40 }));

// // 48
// function negativ(son: number): number {
//   return son <= 0 ? son : -son;
// }
// console.log(negativ(5));

// // 49
// function almash(arr: any[]): any[] {
//   return arr.reverse();
// }
// console.log(almash([1, 2, 3]));

// // 50
// function kinogaKirish(yosh: number, otaOna: boolean): boolean {
//   return yosh >= 15 || otaOna;
// }
// console.log(kinogaKirish(14, true));

// // 51
// function oshir1ga(arr: number[]): number[] {
//   return arr.map(el => el + 1);
// }
// console.log(oshir1ga([1, 2, 3]));

// // 52
// const ism: string = "Donyor";
// const familiya: string = "Olimov";
// const natija: string = `${ism} ${familiya}`;
// console.log(natija);

// // 53
// const holatiYaxshimi: boolean = true;
// const holati: string = holatiYaxshimi ? "yaxshi" : "yaxshi emas";
// console.log(holati);

// // 54
// function sozUzunligi(str: string): boolean {
//   return str.length % 2 === 0;
// }
// console.log(sozUzunligi("salom"));

// // 55
// function daraja(x: number, y: number): number {
//   return x ** y;
// }
// console.log(daraja(2, 3));

// // 56
// function songiElement<T>(arr: T[]): T {
//   return arr[arr.length - 1];
// }
// console.log(songiElement([1, 2, 3]));

// // 57
// function kabisa(yil: number): boolean {
//   return (yil % 4 === 0 && yil % 100 !== 0) || (yil % 400 === 0);
// }
// console.log(kabisa(2020));

// // 58
// function soz(word: string): string {
//   return word.slice(1);
// }
// console.log(soz("salom"));

// // 59
// function teskariBool(bool: boolean): boolean {
//   return !bool;
// }
// console.log(teskariBool(true));

// // 60
// function juftMiToqmi(son: number): string {
//   return son % 2 === 0 ? "juft" : "toq";
// }
// console.log(juftMiToqmi(5));

// // 61
// function qutilar(qavat: number): number {
//   return qavat * qavat;
// }
// console.log(qutilar(4));

// // 62
// function arrayToString(arr: string[]): string {
//   return arr.join('');
// }
// console.log(arrayToString(['s', 'a', 'l', 'o', 'm']));

// // 63
// function birlash<T>(arr1: T[], arr2: T[]): T[] {
//   return [...arr1, ...arr2];
// }
// console.log(birlash([1, 2], [3, 4]));

// // 64
// function topIndex(arr: string[], str: string): number {
//   return arr.indexOf(str);
// }
// console.log(topIndex(["olma", "banan", "gilos"], "banan"));

// // 65
// function arrElement<T>(arr: T[], index: number): T {
//   return arr[Math.floor(index) - 1];
// }
// console.log(arrElement([10, 20, 30, 40], 3));

// // 66
// function namuna(arr: number[]): number {
//   return arr.reduce((a, b) => a + b, 0);
// }
// console.log(namuna([1, 2, 3, 4]));

// // 67
// function sozSon(soz: string): number | undefined {
//   const lugat: { [key: string]: number } = {
//     "nol": 0, "bir": 1, "ikki": 2, "uch": 3, "to’rt": 4,
//     "besh": 5, "olti": 6, "yetti": 7, "sakkiz": 8, "to’qqiz": 9
//   };
//   return lugat[soz];
// }
// console.log(sozSon("besh"));

// // 68
// function bormi(arr: number[], son: number): boolean {
//   return arr.includes(son);
// }
// console.log(bormi([1, 2, 3, 4], 3));

// // 69
// function sonString(arr: number[]): string[] {
//   return arr.map(el => el.toString());
// }
// console.log(sonString([1, 2, 3]));

// // 70
// function kubikchalar(qator: number): number {
//   return qator === 0 ? 0 : 6 * (qator ** 2);
// }
// console.log(kubikchalar(2));

// // 71
// function sayohat(odamlar: number): number {
//   return Math.ceil(odamlar / 5);
// }
// console.log(sayohat(11));

// // 72
// function boshJoy(str: string): boolean {
//   return str.includes(" ");
// }
// console.log(boshJoy("salom dunyo"));

// // 73
// function hajm(quti: { height: number, length: number, width: number }): number {
//   return quti.height * quti.length * quti.width;
// }
// console.log(hajm({ height: 2, length: 3, width: 4 }));

// // 74
// function sonlar(son1: number, son2: number, arr: number[]): number[] {
//   return arr.filter(el => el > son1 && el < son2);
// }
// console.log(sonlar(2, 6, [1, 3, 5, 7]));
